import 'package:flutter/material.dart';

class ColetaDisponivel {
  final String numero;
  final String bairro;
  final String cidade;
  final String material;
  final String pesoEstimado;
  final String valorEstimado;
  final String tempo;
  final String observacao;

  const ColetaDisponivel({
    required this.numero,
    required this.bairro,
    required this.cidade,
    required this.material,
    required this.pesoEstimado,
    required this.valorEstimado,
    required this.tempo,
    required this.observacao,
  });
}

class ColetasDisponiveisPage extends StatelessWidget {
  const ColetasDisponiveisPage({super.key});

  static const List<ColetaDisponivel> _coletas = [
    ColetaDisponivel(
      numero: '10482',
      bairro: 'Centro',
      cidade: 'Barretos',
      material: 'Alumínio',
      pesoEstimado: '15,00 kg',
      valorEstimado: 'R\$ 97,50',
      tempo: '12 min atrás',
      observacao: 'Latas separadas e prontas para coleta.',
    ),
    ColetaDisponivel(
      numero: '10481',
      bairro: 'Los Angeles',
      cidade: 'Barretos',
      material: 'Papelão',
      pesoEstimado: '30,00 kg',
      valorEstimado: 'R\$ 24,00',
      tempo: '18 min atrás',
      observacao: 'Caixas desmontadas e armazenadas em local seco.',
    ),
    ColetaDisponivel(
      numero: '10480',
      bairro: 'América',
      cidade: 'Barretos',
      material: 'PET',
      pesoEstimado: '12,00 kg',
      valorEstimado: 'R\$ 24,00',
      tempo: '25 min atrás',
      observacao: 'Garrafas separadas e sem líquidos.',
    ),
    ColetaDisponivel(
      numero: '10479',
      bairro: 'Pimenta',
      cidade: 'Barretos',
      material: 'Cobre',
      pesoEstimado: '5,00 kg',
      valorEstimado: 'R\$ 125,00',
      tempo: '31 min atrás',
      observacao: 'Fios e cabos separados.',
    ),
    ColetaDisponivel(
      numero: '10478',
      bairro: 'Nogueira',
      cidade: 'Barretos',
      material: 'Plástico',
      pesoEstimado: '20,00 kg',
      valorEstimado: 'R\$ 24,00',
      tempo: '42 min atrás',
      observacao: 'Embalagens plásticas separadas.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        title: const Text(
          'Coletas disponíveis',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: Column(
        children: [
          _buildTopInfo(),

          Expanded(
            child: _coletas.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(
                      16,
                      4,
                      16,
                      24,
                    ),
                    itemCount: _coletas.length,
                    itemBuilder: (context, index) {
                      return _buildCollectionCard(
                        context,
                        _coletas[index],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopInfo() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: Colors.green.withValues(alpha: 0.15),
        ),
      ),
      child: const Row(
        children: [
          Icon(
            Icons.location_on_outlined,
            color: Colors.green,
          ),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'Solicitações disponíveis na sua região',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ),
          Icon(
            Icons.filter_list_outlined,
            color: Colors.green,
          ),
        ],
      ),
    );
  }

  Widget _buildCollectionCard(
    BuildContext context,
    ColetaDisponivel coleta,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DetalhesColetaPage(
                coleta: coleta,
              ),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(17),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: Colors.green.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(
                      Icons.local_shipping_outlined,
                      color: Colors.green,
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Coleta #${coleta.numero}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          coleta.tempo,
                          style: TextStyle(
                            color: Colors.grey.shade500,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const Icon(
                    Icons.chevron_right,
                    color: Colors.grey,
                  ),
                ],
              ),

              const SizedBox(height: 16),

              _buildInfoRow(
                Icons.location_on_outlined,
                '${coleta.bairro}, ${coleta.cidade}',
              ),

              const SizedBox(height: 9),

              _buildInfoRow(
                Icons.recycling_outlined,
                coleta.material,
              ),

              const SizedBox(height: 9),

              _buildInfoRow(
                Icons.scale_outlined,
                'Peso estimado: ${coleta.pesoEstimado}',
              ),

              const SizedBox(height: 14),

              const Divider(),

              const SizedBox(height: 10),

              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Valor estimado',
                      style: TextStyle(
                        color: Colors.grey.shade600,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  Text(
                    coleta.valorEstimado,
                    style: const TextStyle(
                      color: Colors.green,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              SizedBox(
                width: double.infinity,
                height: 44,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetalhesColetaPage(
                          coleta: coleta,
                        ),
                      ),
                    );
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.green,
                    side: const BorderSide(
                      color: Colors.green,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Ver detalhes',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(
    IconData icon,
    String text,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          color: Colors.grey.shade600,
          size: 19,
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              color: Colors.grey.shade700,
              fontSize: 13,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.local_shipping_outlined,
              size: 70,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 20),
            const Text(
              'Nenhuma coleta disponível',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Quando novas solicitações aparecerem na sua região, elas serão mostradas aqui.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.grey.shade600,
                fontSize: 14,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DetalhesColetaPage extends StatelessWidget {
  final ColetaDisponivel coleta;

  const DetalhesColetaPage({
    super.key,
    required this.coleta,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        title: Text(
          'Coleta #${coleta.numero}',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildStatus(),

              const SizedBox(height: 20),

              const Text(
                'Detalhes da solicitação',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              _buildDetailsCard(),

              const SizedBox(height: 20),

              const Text(
                'Local da coleta',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              _buildLocationCard(),

              const SizedBox(height: 20),

              const Text(
                'Observação do usuário',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              _buildObservationCard(),

              const SizedBox(height: 28),

              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: () {
                    _mostrarConfirmacao(context);
                  },
                  icon: const Icon(
                    Icons.check_circle_outline,
                  ),
                  label: const Text(
                    'Aceitar coleta',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.grey.shade700,
                    side: BorderSide(
                      color: Colors.grey.shade300,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    'Voltar',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatus() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.orange.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: Colors.orange.withValues(alpha: 0.15),
        ),
      ),
      child: const Row(
        children: [
          Icon(
            Icons.access_time,
            color: Colors.orange,
          ),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'Esta coleta está aguardando um coletor.',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailsCard() {
    return _buildCard(
      child: Column(
        children: [
          _buildDetailRow(
            Icons.recycling_outlined,
            'Material',
            coleta.material,
          ),
          const Divider(height: 24),
          _buildDetailRow(
            Icons.scale_outlined,
            'Peso estimado',
            coleta.pesoEstimado,
          ),
          const Divider(height: 24),
          _buildDetailRow(
            Icons.attach_money,
            'Valor estimado',
            coleta.valorEstimado,
          ),
        ],
      ),
    );
  }

  Widget _buildLocationCard() {
    return _buildCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: Colors.green.withValues(alpha: 0.10),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.location_on_outlined,
              color: Colors.green,
            ),
          ),

          const SizedBox(width: 12),

          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Endereço',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  'Bairro da solicitação',
                  style: TextStyle(
                    fontSize: 13,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'A localização completa será disponibilizada conforme as regras de acesso da coleta.',
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildObservationCard() {
    return _buildCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.notes_outlined,
            color: Colors.green,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              coleta.observacao,
              style: TextStyle(
                color: Colors.grey.shade700,
                fontSize: 13,
                height: 1.45,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCard({
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _buildDetailRow(
    IconData icon,
    String title,
    String value,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          color: Colors.green,
          size: 23,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 13,
            ),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  void _mostrarConfirmacao(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Aceitar esta coleta?',
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(
            'Você está prestes a aceitar a coleta #${coleta.numero}. '
            'Confira os dados antes de continuar.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text(
                'Voltar',
                style: TextStyle(
                  color: Colors.grey,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(dialogContext);

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Coleta aceita. A integração com a rota será feita na próxima etapa.',
                    ),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                elevation: 0,
              ),
              child: const Text(
                'Aceitar',
              ),
            ),
          ],
        );
      },
    );
  }
}
import 'package:flutter/material.dart';

import '../app_data.dart';

class PontosPage extends StatelessWidget {
  const PontosPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9F7),
      appBar: AppBar(
        title: const Text(
          'Meus pontos',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Seus pontos',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 6),

              Text(
                'Acompanhe seus pontos e descubra como participar.',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade600,
                ),
              ),

              const SizedBox(height: 20),

              _PontosPrincipal(
                pontos: AppData.pontos,
              ),

              const SizedBox(height: 20),

              _MensagemPontos(),

              const SizedBox(height: 28),

              const Text(
                'Como ganhar pontos?',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 12),

              const _FormaDeGanhar(
                icone: Icons.recycling_outlined,
                titulo: 'Recicle materiais',
                descricao:
                    'Solicite uma coleta e entregue seus materiais '
                    'recicláveis para a equipe.',
              ),

              const SizedBox(height: 10),

              const _FormaDeGanhar(
                icone: Icons.scale_outlined,
                titulo: 'Tenha seus materiais pesados',
                descricao:
                    'A quantidade de pontos poderá considerar a '
                    'quantidade de material reciclado.',
              ),

              const SizedBox(height: 10),

              const _FormaDeGanhar(
                icone: Icons.eco_outlined,
                titulo: 'Ajude o meio ambiente',
                descricao:
                    'Quanto mais você participa da reciclagem, '
                    'maior pode ser sua contribuição para a comunidade.',
              ),

              const SizedBox(height: 28),

              const Text(
                'Sobre os pontos',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 12),

              _InformacaoPontos(),
            ],
          ),
        ),
      ),
    );
  }
}

class _PontosPrincipal extends StatelessWidget {
  final int pontos;

  const _PontosPrincipal({
    required this.pontos,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(26),
      decoration: BoxDecoration(
        color: Colors.green.shade700,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.stars_rounded,
              color: Colors.white,
              size: 38,
            ),
          ),

          const SizedBox(height: 16),

          const Text(
            'Você possui',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
          ),

          const SizedBox(height: 5),

          Text(
            pontos.toString(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 38,
              fontWeight: FontWeight.w900,
            ),
          ),

          const SizedBox(height: 3),

          const Text(
            'pontos',
            style: TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _MensagemPontos extends StatelessWidget {
  const _MensagemPontos();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.lightbulb_outline,
            color: Colors.green.shade700,
            size: 25,
          ),

          const SizedBox(width: 13),

          Expanded(
            child: Text(
              'Seus pontos são acumulados conforme você participa '
              'do programa de reciclagem. As regras de conversão '
              'e resgate serão definidas no sistema.',
              style: TextStyle(
                fontSize: 13,
                height: 1.5,
                color: Colors.grey.shade700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FormaDeGanhar extends StatelessWidget {
  final IconData icone;
  final String titulo;
  final String descricao;

  const _FormaDeGanhar({
    required this.icone,
    required this.titulo,
    required this.descricao,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 47,
            height: 47,
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(
              icone,
              color: Colors.green.shade700,
              size: 24,
            ),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titulo,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),

                const SizedBox(height: 5),

                Text(
                  descricao,
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InformacaoPontos extends StatelessWidget {
  const _InformacaoPontos();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(19),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.green.shade100,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.info_outline,
                color: Colors.green.shade700,
              ),

              const SizedBox(width: 10),

              Text(
                'Importante',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: Colors.green.shade900,
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          Text(
            'A quantidade de pontos recebida e as regras de '
            'conversão para dinheiro serão definidas pela plataforma. '
            'Essas informações poderão ser atualizadas futuramente '
            'sem precisar alterar esta tela.',
            style: TextStyle(
              fontSize: 13,
              height: 1.5,
              color: Colors.green.shade900,
            ),
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';

import '../app_data.dart';

class EditarEnderecoPage extends StatefulWidget {
  const EditarEnderecoPage({super.key});

  @override
  State<EditarEnderecoPage> createState() => _EditarEnderecoPageState();
}

class _EditarEnderecoPageState extends State<EditarEnderecoPage> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _estadoController;
  late final TextEditingController _cidadeController;
  late final TextEditingController _bairroController;
  late final TextEditingController _ruaController;
  late final TextEditingController _numeroController;
  late final TextEditingController _complementoController;

  String? _tipoResidencia;

  final List<String> _tiposResidencia = [
    'Casa',
    'Apartamento',
    'Condomínio',
    'Outro',
  ];

  @override
  void initState() {
    super.initState();

    _estadoController = TextEditingController(
      text: AppData.estado ?? '',
    );

    _cidadeController = TextEditingController(
      text: AppData.cidade ?? '',
    );

    _bairroController = TextEditingController(
      text: AppData.bairro ?? '',
    );

    _ruaController = TextEditingController(
      text: AppData.rua ?? '',
    );

    _numeroController = TextEditingController(
      text: AppData.numero ?? '',
    );

    _complementoController = TextEditingController(
      text: AppData.complemento ?? '',
    );

    _tipoResidencia = AppData.tipoResidencia;
  }

  @override
  void dispose() {
    _estadoController.dispose();
    _cidadeController.dispose();
    _bairroController.dispose();
    _ruaController.dispose();
    _numeroController.dispose();
    _complementoController.dispose();

    super.dispose();
  }

  String? validarObrigatorio(
    String? valor,
    String campo,
  ) {
    if (valor == null || valor.trim().isEmpty) {
      return 'Informe $campo.';
    }

    return null;
  }

  void salvarEndereco() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_tipoResidencia == null ||
        _tipoResidencia!.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Selecione o tipo de residência.',
          ),
        ),
      );
      return;
    }

    AppData.salvarEndereco(
      novoEstado: _estadoController.text.trim(),
      novaCidade: _cidadeController.text.trim(),
      novoBairro: _bairroController.text.trim(),
      novaRua: _ruaController.text.trim(),
      novoNumero: _numeroController.text.trim(),
      novoComplemento: _complementoController.text.trim(),
      novoTipoResidencia: _tipoResidencia!,
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Endereço atualizado com sucesso!',
        ),
      ),
    );

    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9F7),
      appBar: AppBar(
        title: const Text(
          'Editar endereço',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(
              20,
              20,
              20,
              32,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Local da coleta',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  'Mantenha seu endereço atualizado para que '
                  'a equipe consiga encontrar o local da coleta.',
                  style: TextStyle(
                    fontSize: 14,
                    height: 1.4,
                    color: Colors.grey.shade600,
                  ),
                ),

                const SizedBox(height: 24),

                _CampoEndereco(
                  controller: _estadoController,
                  titulo: 'Estado',
                  icone: Icons.map_outlined,
                  teclado: TextInputType.text,
                  validator: (valor) {
                    return validarObrigatorio(
                      valor,
                      'o estado',
                    );
                  },
                ),

                const SizedBox(height: 15),

                _CampoEndereco(
                  controller: _cidadeController,
                  titulo: 'Cidade',
                  icone: Icons.location_city_outlined,
                  teclado: TextInputType.text,
                  validator: (valor) {
                    return validarObrigatorio(
                      valor,
                      'a cidade',
                    );
                  },
                ),

                const SizedBox(height: 15),

                _CampoEndereco(
                  controller: _bairroController,
                  titulo: 'Bairro',
                  icone: Icons.apartment_outlined,
                  teclado: TextInputType.text,
                  validator: (valor) {
                    return validarObrigatorio(
                      valor,
                      'o bairro',
                    );
                  },
                ),

                const SizedBox(height: 15),

                _CampoEndereco(
                  controller: _ruaController,
                  titulo: 'Rua',
                  icone: Icons.signpost_outlined,
                  teclado: TextInputType.streetAddress,
                  validator: (valor) {
                    return validarObrigatorio(
                      valor,
                      'a rua',
                    );
                  },
                ),

                const SizedBox(height: 15),

                _CampoEndereco(
                  controller: _numeroController,
                  titulo: 'Número',
                  icone: Icons.pin_outlined,
                  teclado: TextInputType.number,
                  validator: (valor) {
                    return validarObrigatorio(
                      valor,
                      'o número',
                    );
                  },
                ),

                const SizedBox(height: 15),

                _CampoEndereco(
                  controller: _complementoController,
                  titulo: 'Complemento',
                  icone: Icons.home_work_outlined,
                  teclado: TextInputType.text,
                  obrigatorio: false,
                ),

                const SizedBox(height: 18),

                DropdownButtonFormField<String>(
                  initialValue: _tipoResidencia,
                  decoration: InputDecoration(
                    labelText: 'Tipo de residência',
                    prefixIcon: Icon(
                      Icons.home_outlined,
                      color: Colors.green.shade700,
                    ),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide(
                        color: Colors.grey.shade200,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide(
                        color: Colors.grey.shade200,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide(
                        color: Colors.green.shade600,
                        width: 1.5,
                      ),
                    ),
                  ),
                  items: _tiposResidencia.map(
                    (tipo) {
                      return DropdownMenuItem<String>(
                        value: tipo,
                        child: Text(tipo),
                      );
                    },
                  ).toList(),
                  onChanged: (valor) {
                    setState(() {
                      _tipoResidencia = valor;
                    });
                  },
                  validator: (valor) {
                    if (valor == null || valor.isEmpty) {
                      return 'Selecione o tipo de residência.';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 22),

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: Colors.green.shade100,
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: Colors.green.shade700,
                      ),

                      const SizedBox(width: 11),

                      Expanded(
                        child: Text(
                          'Esse endereço será utilizado como local '
                          'para a coleta dos materiais recicláveis.',
                          style: TextStyle(
                            fontSize: 12,
                            height: 1.45,
                            color: Colors.green.shade900,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: salvarEndereco,
                    icon: const Icon(
                      Icons.save_outlined,
                    ),
                    label: const Text(
                      'Salvar endereço',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade700,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(
                        vertical: 15,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.grey.shade700,
                      side: BorderSide(
                        color: Colors.grey.shade300,
                      ),
                      padding: const EdgeInsets.symmetric(
                        vertical: 14,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13),
                      ),
                    ),
                    child: const Text(
                      'Cancelar',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CampoEndereco extends StatelessWidget {
  final TextEditingController controller;
  final String titulo;
  final IconData icone;
  final TextInputType teclado;
  final String? Function(String?)? validator;
  final bool obrigatorio;

  const _CampoEndereco({
    required this.controller,
    required this.titulo,
    required this.icone,
    required this.teclado,
    this.validator,
    this.obrigatorio = true,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: teclado,
      validator: obrigatorio ? validator : null,
      decoration: InputDecoration(
        labelText: titulo,
        prefixIcon: Icon(
          icone,
          color: Colors.green.shade700,
        ),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.grey.shade200,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.grey.shade200,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.green.shade600,
            width: 1.5,
          ),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.red.shade300,
          ),
        ),
      ),
    );
  }
}
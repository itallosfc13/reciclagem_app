import 'package:flutter/material.dart';
import '../app_data.dart';
import '../material_data.dart';
import 'status_page.dart';

class ConfirmacaoPage extends StatelessWidget {
  final List<String> materiais;
  final String quantidade;
  final String observacao;

  const ConfirmacaoPage({
    super.key,
    required this.materiais,
    required this.quantidade,
    this.observacao = '',
  });

  double get peso {
    final texto = quantidade
        .replaceAll('kg', '')
        .replaceAll(',', '.')
        .trim();

    return double.tryParse(texto) ?? 0;
  }

  double get valorEstimado {
    if (materiais.isEmpty) {
      return 0;
    }

    final material = MaterialData.materiais.firstWhere(
      (item) => item.nome == materiais.first,
    );

    return material.valorPorKg * peso;
  }

  String formatarDinheiro(double valor) {
    return 'R\$ ${valor.toStringAsFixed(2).replaceAll('.', ',')}';
  }

  String get enderecoCompleto {
    if (AppData.rua == null ||
        AppData.numero == null ||
        AppData.bairro == null ||
        AppData.cidade == null ||
        AppData.estado == null) {
      return 'Endereço não informado';
    }

    return '${AppData.rua}, ${AppData.numero}'
        '${AppData.complemento != null && AppData.complemento!.isNotEmpty ? ' - ${AppData.complemento}' : ''}'
        ' - ${AppData.bairro}, '
        '${AppData.cidade} - ${AppData.estado}';
  }

  void confirmarColeta(BuildContext context) {
    if (materiais.isEmpty || peso <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Não foi possível confirmar os dados da coleta.',
          ),
        ),
      );
      return;
    }

    AppData.solicitarColeta(
      material: materiais.first,
      peso: peso,
      observacao: observacao,
    );

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => StatusPage(
          materiais: materiais,
          quantidade: quantidade,
          observacao: observacao,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final materialNome =
        materiais.isNotEmpty
            ? materiais.first
            : 'Material não informado';

    MaterialReciclavel? material;

    for (final item in MaterialData.materiais) {
      if (item.nome == materialNome) {
        material = item;
        break;
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Confirmar coleta',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Confira sua coleta',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              'Verifique se todas as informações estão corretas antes de solicitar.',
              style: TextStyle(
                fontSize: 16,
              ),
            ),

            const SizedBox(height: 30),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(
                        Icons.recycling,
                        size: 28,
                      ),
                      SizedBox(width: 10),
                      Text(
                        'Material',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),

                  Row(
                    children: [
                      if (material != null)
                        Icon(
                          material.icone,
                          size: 38,
                        ),

                      const SizedBox(width: 14),

                      Expanded(
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            Text(
                              materialNome,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            const SizedBox(height: 4),

                            if (material != null)
                              Text(
                                'Valor aproximado: '
                                '${formatarDinheiro(material.valorPorKg)}/kg',
                                style: TextStyle(
                                  color:
                                      Colors.grey.shade700,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 18),

            _InfoCard(
              icon: Icons.scale_outlined,
              titulo: 'Quantidade aproximada',
              valor: quantidade,
            ),

            const SizedBox(height: 18),

            _InfoCard(
              icon: Icons.attach_money,
              titulo: 'Valor estimado',
              valor: formatarDinheiro(
                valorEstimado,
              ),
            ),

            const SizedBox(height: 18),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: Colors.grey.shade300,
                ),
              ),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(
                        Icons.location_on_outlined,
                        size: 28,
                      ),
                      SizedBox(width: 10),
                      Text(
                        'Endereço',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),

                  Text(
                    enderecoCompleto,
                    style: const TextStyle(
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),

            if (observacao.isNotEmpty) ...[
              const SizedBox(height: 18),

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius:
                      BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.grey.shade300,
                  ),
                ),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(
                          Icons.notes_outlined,
                          size: 28,
                        ),
                        SizedBox(width: 10),
                        Text(
                          'Observações',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 12),

                    Text(
                      observacao,
                      style: const TextStyle(
                        fontSize: 15,
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 24),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: Colors.orange.shade200,
                ),
              ),
              child: Row(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.info_outline,
                    color: Colors.orange.shade800,
                    size: 28,
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: Text(
                      'O valor exibido é apenas uma estimativa. '
                      'O peso e o valor finais serão definidos '
                      'pela equipe durante a pesagem.',
                      style: TextStyle(
                        fontSize: 14,
                        color:
                            Colors.orange.shade900,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: () {
                  confirmarColeta(context);
                },
                icon: const Icon(
                  Icons.check_circle_outline,
                ),
                label: const Text(
                  'CONFIRMAR COLETA',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 12),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text(
                  'VOLTAR E EDITAR',
                ),
              ),
            ),

            const SizedBox(height: 25),

            const Center(
              child: Text(
                'Ao confirmar, sua solicitação será enviada para nossa equipe.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                ),
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String titulo;
  final String valor;

  const _InfoCard({
    required this.icon,
    required this.titulo,
    required this.valor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.grey.shade300,
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            size: 30,
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  titulo,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade600,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  valor,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
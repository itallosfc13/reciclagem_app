import 'package:flutter/material.dart';

class ConfiguracoesPage extends StatefulWidget {
  const ConfiguracoesPage({super.key});

  @override
  State<ConfiguracoesPage> createState() => _ConfiguracoesPageState();
}

class _ConfiguracoesPageState extends State<ConfiguracoesPage> {
  bool _notificacoesAtivas = true;
  bool _notificacoesColeta = true;
  bool _notificacoesPontos = true;
  bool _localizacaoAtiva = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        title: const Text(
          'Configurações',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionTitle('Notificações'),

          _buildSwitchTile(
            icon: Icons.notifications_outlined,
            title: 'Notificações',
            subtitle: 'Receba avisos importantes do aplicativo',
            value: _notificacoesAtivas,
            onChanged: (value) {
              setState(() {
                _notificacoesAtivas = value;

                if (!value) {
                  _notificacoesColeta = false;
                  _notificacoesPontos = false;
                }
              });
            },
          ),

          _buildSwitchTile(
            icon: Icons.local_shipping_outlined,
            title: 'Atualizações da coleta',
            subtitle: 'Avisos sobre o andamento das suas coletas',
            value: _notificacoesColeta,
            enabled: _notificacoesAtivas,
            onChanged: (value) {
              setState(() {
                _notificacoesColeta = value;
              });
            },
          ),

          _buildSwitchTile(
            icon: Icons.stars_outlined,
            title: 'Pontos e recompensas',
            subtitle: 'Avisos sobre pontos, saldo e recompensas',
            value: _notificacoesPontos,
            enabled: _notificacoesAtivas,
            onChanged: (value) {
              setState(() {
                _notificacoesPontos = value;
              });
            },
          ),

          const SizedBox(height: 24),

          _buildSectionTitle('Privacidade e localização'),

          _buildSwitchTile(
            icon: Icons.location_on_outlined,
            title: 'Localização',
            subtitle: 'Permitir o uso da localização para coletas',
            value: _localizacaoAtiva,
            onChanged: (value) {
              setState(() {
                _localizacaoAtiva = value;
              });
            },
          ),

          const SizedBox(height: 24),

          _buildSectionTitle('Conta'),

          _buildActionTile(
            icon: Icons.lock_outline,
            title: 'Segurança da conta',
            subtitle: 'Senha e outras opções de segurança',
            onTap: () {
              _mostrarMensagem(
                'A área de segurança será implementada junto ao sistema de autenticação.',
              );
            },
          ),

          _buildActionTile(
            icon: Icons.privacy_tip_outlined,
            title: 'Privacidade',
            subtitle: 'Veja como seus dados são utilizados',
            onTap: () {
              _mostrarPrivacidade();
            },
          ),

          const SizedBox(height: 24),

          _buildSectionTitle('Ajuda'),

          _buildActionTile(
            icon: Icons.help_outline,
            title: 'Central de ajuda',
            subtitle: 'Tire suas dúvidas sobre o aplicativo',
            onTap: () {
              _mostrarMensagem(
                'A Central de Ajuda será adicionada em uma próxima etapa.',
              );
            },
          ),

          _buildActionTile(
            icon: Icons.info_outline,
            title: 'Sobre o aplicativo',
            subtitle: 'Informações sobre a plataforma',
            onTap: () {
              _mostrarSobre();
            },
          ),

          const SizedBox(height: 30),

          Center(
            child: Text(
              'Versão 1.0.0',
              style: TextStyle(
                color: Colors.grey.shade600,
                fontSize: 13,
              ),
            ),
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 4,
        bottom: 10,
      ),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.bold,
          color: Colors.black87,
        ),
      ),
    );
  }

  Widget _buildSwitchTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
    bool enabled = true,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: SwitchListTile(
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 6,
        ),
        secondary: Icon(
          icon,
          color: enabled ? Colors.green : Colors.grey,
          size: 25,
        ),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: enabled ? Colors.black87 : Colors.grey,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(
            fontSize: 13,
            color: enabled
                ? Colors.grey.shade600
                : Colors.grey.shade400,
          ),
        ),
        value: value,
        onChanged: enabled ? onChanged : null,
      ),
    );
  }

  Widget _buildActionTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 6,
        ),
        leading: Icon(
          icon,
          color: Colors.green,
          size: 25,
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey.shade600,
          ),
        ),
        trailing: const Icon(
          Icons.chevron_right,
          color: Colors.grey,
        ),
        onTap: onTap,
      ),
    );
  }

  void _mostrarMensagem(String mensagem) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensagem),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _mostrarPrivacidade() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Privacidade'),
          content: const Text(
            'Seus dados pessoais devem ser utilizados apenas '
            'para as funcionalidades necessárias do aplicativo. '
            'Na versão final, esta área será integrada às '
            'regras de privacidade e proteção de dados da plataforma.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Fechar'),
            ),
          ],
        );
      },
    );
  }

  void _mostrarSobre() {
    showAboutDialog(
      context: context,
      applicationName: 'Reciclagem',
      applicationVersion: '1.0.0',
      applicationIcon: const Icon(
        Icons.recycling,
        color: Colors.green,
        size: 40,
      ),
      children: const [
        Text(
          'Uma plataforma criada para facilitar a '
          'reciclagem, conectar usuários às coletas '
          'e incentivar a participação por meio de pontos '
          'e recompensas.',
        ),
      ],
    );
  }
}
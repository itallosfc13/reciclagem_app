import 'package:flutter/material.dart';

import '../app_data.dart';

class EditarPerfilPage extends StatefulWidget {
  const EditarPerfilPage({super.key});

  @override
  State<EditarPerfilPage> createState() => _EditarPerfilPageState();
}

class _EditarPerfilPageState extends State<EditarPerfilPage> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _nomeController;
  late final TextEditingController _emailController;
  late final TextEditingController _telefoneController;
  late final TextEditingController _cpfController;

  @override
  void initState() {
    super.initState();

    _nomeController = TextEditingController(
      text: AppData.nome ?? '',
    );

    _emailController = TextEditingController(
      text: AppData.email ?? '',
    );

    _telefoneController = TextEditingController(
      text: AppData.telefone ?? '',
    );

    _cpfController = TextEditingController(
      text: AppData.cpf ?? '',
    );
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _emailController.dispose();
    _telefoneController.dispose();
    _cpfController.dispose();

    super.dispose();
  }

  String? validarCampoObrigatorio(
    String? valor,
    String nomeCampo,
  ) {
    if (valor == null || valor.trim().isEmpty) {
      return 'Informe $nomeCampo.';
    }

    return null;
  }

  void salvarAlteracoes() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      AppData.nome = _nomeController.text.trim();
      AppData.email = _emailController.text.trim();
      AppData.telefone = _telefoneController.text.trim();
      AppData.cpf = _cpfController.text.trim();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Perfil atualizado com sucesso!',
        ),
      ),
    );

    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9F7),
      appBar: AppBar(
        title: const Text(
          'Editar perfil',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Dados pessoais',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  'Mantenha seus dados sempre atualizados.',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade600,
                  ),
                ),

                const SizedBox(height: 24),

                _CampoTexto(
                  controller: _nomeController,
                  titulo: 'Nome completo',
                  icone: Icons.person_outline,
                  teclado: TextInputType.name,
                  validator: (valor) {
                    return validarCampoObrigatorio(
                      valor,
                      'seu nome',
                    );
                  },
                ),

                const SizedBox(height: 16),

                _CampoTexto(
                  controller: _emailController,
                  titulo: 'E-mail',
                  icone: Icons.email_outlined,
                  teclado: TextInputType.emailAddress,
                  validator: (valor) {
                    final erro = validarCampoObrigatorio(
                      valor,
                      'seu e-mail',
                    );

                    if (erro != null) {
                      return erro;
                    }

                    if (!valor!.contains('@')) {
                      return 'Informe um e-mail válido.';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 16),

                _CampoTexto(
                  controller: _telefoneController,
                  titulo: 'Telefone',
                  icone: Icons.phone_outlined,
                  teclado: TextInputType.phone,
                  validator: (valor) {
                    return validarCampoObrigatorio(
                      valor,
                      'seu telefone',
                    );
                  },
                ),

                const SizedBox(height: 16),

                _CampoTexto(
                  controller: _cpfController,
                  titulo: 'CPF',
                  icone: Icons.badge_outlined,
                  teclado: TextInputType.number,
                  validator: (valor) {
                    return validarCampoObrigatorio(
                      valor,
                      'seu CPF',
                    );
                  },
                ),

                const SizedBox(height: 28),

                const Text(
                  'Endereço',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  'Para alterar seu endereço, utilize a opção '
                  'de endereço da conta.',
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.4,
                    color: Colors.grey.shade600,
                  ),
                ),

                const SizedBox(height: 14),

                _EnderecoResumo(),

                const SizedBox(height: 28),

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.orange.shade50,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: Colors.orange.shade100,
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.lock_outline,
                        color: Colors.orange.shade800,
                        size: 22,
                      ),

                      const SizedBox(width: 11),

                      Expanded(
                        child: Text(
                          'Seus dados pessoais devem ser mantidos '
                          'em segurança. Em uma versão conectada '
                          'ao servidor, essas informações serão '
                          'protegidas pelo sistema de autenticação.',
                          style: TextStyle(
                            fontSize: 12,
                            height: 1.45,
                            color: Colors.orange.shade900,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: salvarAlteracoes,
                    icon: const Icon(
                      Icons.save_outlined,
                    ),
                    label: const Text(
                      'Salvar alterações',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade700,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(
                        vertical: 15,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.grey.shade700,
                      side: BorderSide(
                        color: Colors.grey.shade300,
                      ),
                      padding: const EdgeInsets.symmetric(
                        vertical: 14,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13),
                      ),
                    ),
                    child: const Text(
                      'Cancelar',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CampoTexto extends StatelessWidget {
  final TextEditingController controller;
  final String titulo;
  final IconData icone;
  final TextInputType teclado;
  final String? Function(String?)? validator;

  const _CampoTexto({
    required this.controller,
    required this.titulo,
    required this.icone,
    required this.teclado,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: teclado,
      validator: validator,
      decoration: InputDecoration(
        labelText: titulo,
        prefixIcon: Icon(
          icone,
          color: Colors.green.shade700,
        ),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.grey.shade200,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.grey.shade200,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.green.shade600,
            width: 1.5,
          ),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: Colors.red.shade300,
          ),
        ),
      ),
    );
  }
}

class _EnderecoResumo extends StatelessWidget {
  const _EnderecoResumo();

  String valor(String? texto) {
    if (texto == null || texto.trim().isEmpty) {
      return 'Não informado';
    }

    return texto;
  }

  String montarEndereco() {
    final partes = <String>[];

    if (AppData.rua != null && AppData.rua!.isNotEmpty) {
      partes.add(AppData.rua!);
    }

    if (AppData.numero != null &&
        AppData.numero!.isNotEmpty) {
      partes.add('nº ${AppData.numero!}');
    }

    if (AppData.complemento != null &&
        AppData.complemento!.isNotEmpty) {
      partes.add(AppData.complemento!);
    }

    if (AppData.bairro != null &&
        AppData.bairro!.isNotEmpty) {
      partes.add(AppData.bairro!);
    }

    if (AppData.cidade != null &&
        AppData.cidade!.isNotEmpty) {
      partes.add(AppData.cidade!);
    }

    if (AppData.estado != null &&
        AppData.estado!.isNotEmpty) {
      partes.add(AppData.estado!);
    }

    if (partes.isEmpty) {
      return 'Endereço não informado';
    }

    return partes.join(', ');
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                Icons.location_on_outlined,
                color: Colors.green.shade700,
                size: 25,
              ),

              const SizedBox(width: 11),

              Expanded(
                child: Text(
                  montarEndereco(),
                  style: const TextStyle(
                    fontSize: 14,
                    height: 1.45,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          Divider(
            color: Colors.grey.shade200,
          ),

          const SizedBox(height: 12),

          Row(
            children: [
              Icon(
                Icons.home_outlined,
                color: Colors.grey.shade600,
                size: 20,
              ),

              const SizedBox(width: 9),

              Text(
                'Tipo: ${valor(AppData.tipoResidencia)}',
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.grey.shade700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';

import '../app_data.dart';
import '../material_data.dart';
import 'home_page.dart';

class StatusPage extends StatelessWidget {
  final List<String> materiais;
  final String quantidade;
  final String observacao;

  const StatusPage({
    super.key,
    required this.materiais,
    required this.quantidade,
    this.observacao = '',
  });

  double get peso {
    final texto = quantidade.replaceAll('kg', '').trim().replaceAll(',', '.');
    return double.tryParse(texto) ?? 0;
  }

  double get valorEstimado {
    if (materiais.isEmpty) return 0;

    final nomeMaterial = materiais.first;

    try {
      final material = MaterialData.materiais.firstWhere(
        (item) => item.nome == nomeMaterial,
      );

      return material.valorPorKg * peso;
    } catch (_) {
      return 0;
    }
  }

  String formatarDinheiro(double valor) {
    return 'R\$ ${valor.toStringAsFixed(2).replaceAll('.', ',')}';
  }

  String get endereco {
    final partes = <String>[];

    if (AppData.rua != null && AppData.rua!.isNotEmpty) {
      partes.add(AppData.rua!);
    }

    if (AppData.numero != null && AppData.numero!.isNotEmpty) {
      partes.add('nº ${AppData.numero!}');
    }

    if (AppData.complemento != null &&
        AppData.complemento!.isNotEmpty) {
      partes.add(AppData.complemento!);
    }

    if (AppData.bairro != null && AppData.bairro!.isNotEmpty) {
      partes.add(AppData.bairro!);
    }

    if (AppData.cidade != null && AppData.cidade!.isNotEmpty) {
      partes.add(AppData.cidade!);
    }

    if (AppData.estado != null && AppData.estado!.isNotEmpty) {
      partes.add(AppData.estado!);
    }

    if (partes.isEmpty) {
      return 'Endereço não informado';
    }

    return partes.join(', ');
  }

  String gerarNumeroSolicitacao() {
    final agora = DateTime.now();

    return '${agora.year}'
        '${agora.month.toString().padLeft(2, '0')}'
        '${agora.day.toString().padLeft(2, '0')}'
        '${agora.hour.toString().padLeft(2, '0')}'
        '${agora.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final solicitacaoAtiva = AppData.coletaSolicitada;

    return Scaffold(
      backgroundColor: const Color(0xFFF7F9F7),
      appBar: AppBar(
        title: const Text(
          'Acompanhar coleta',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _StatusHeader(
                solicitacaoAtiva: solicitacaoAtiva,
              ),
              const SizedBox(height: 24),

              _buildTimeline(),
              const SizedBox(height: 24),

              _buildResumo(),
              const SizedBox(height: 16),

              _buildEndereco(),
              const SizedBox(height: 16),

              if (observacao.isNotEmpty) ...[
                _buildObservacao(),
                const SizedBox(height: 16),
              ],

              _buildInfoPagamento(),
              const SizedBox(height: 28),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const HomePage(),
                      ),
                      (route) => false,
                    );
                  },
                  icon: const Icon(Icons.home_outlined),
                  label: const Text(
                    'Voltar para o início',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade700,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTimeline() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Status da solicitação',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 20),

          _StatusStep(
            titulo: 'Solicitação recebida',
            descricao: 'Sua solicitação foi registrada.',
            concluido: true,
            ultimo: false,
          ),

          _StatusStep(
            titulo: 'Aguardando agendamento',
            descricao: 'Estamos organizando a coleta.',
            concluido: true,
            ultimo: false,
          ),

          _StatusStep(
            titulo: 'Coleta agendada',
            descricao: 'O próximo passo será definir a coleta.',
            concluido: false,
            ultimo: false,
          ),

          _StatusStep(
            titulo: 'Coletor a caminho',
            descricao: 'O coletor irá até o endereço informado.',
            concluido: false,
            ultimo: false,
          ),

          _StatusStep(
            titulo: 'Pesagem',
            descricao: 'Os materiais serão pesados no momento da coleta.',
            concluido: false,
            ultimo: false,
          ),

          _StatusStep(
            titulo: 'Coleta concluída',
            descricao:
                'Pagamento e pontos serão calculados após a pesagem.',
            concluido: false,
            ultimo: true,
          ),
        ],
      ),
    );
  }

  Widget _buildResumo() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Resumo da coleta',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 16),

          _InfoRow(
            icone: Icons.recycling_outlined,
            titulo: 'Material',
            valor: materiais.isEmpty
                ? 'Não informado'
                : materiais.join(', '),
          ),

          const SizedBox(height: 14),

          _InfoRow(
            icone: Icons.scale_outlined,
            titulo: 'Quantidade aproximada',
            valor: quantidade,
          ),

          const SizedBox(height: 14),

          _InfoRow(
            icone: Icons.payments_outlined,
            titulo: 'Valor estimado',
            valor: formatarDinheiro(valorEstimado),
            destaque: true,
          ),

          const SizedBox(height: 14),

          _InfoRow(
            icone: Icons.confirmation_number_outlined,
            titulo: 'Solicitação',
            valor: '#${gerarNumeroSolicitacao()}',
          ),
        ],
      ),
    );
  }

  Widget _buildEndereco() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Local da coleta',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 14),

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.location_on_outlined,
                  color: Colors.green.shade700,
                ),
              ),
              const SizedBox(width: 12),

              Expanded(
                child: Text(
                  endereco,
                  style: const TextStyle(
                    fontSize: 15,
                    height: 1.4,
                    color: Colors.black87,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildObservacao() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Observação',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 12),

          Text(
            observacao,
            style: const TextStyle(
              fontSize: 15,
              height: 1.4,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoPagamento() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.green.shade100,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.info_outline,
            color: Colors.green.shade700,
          ),
          const SizedBox(width: 12),

          Expanded(
            child: Text(
              'O valor mostrado é apenas uma estimativa. '
              'O pagamento será calculado com base no peso real '
              'verificado pela equipe durante a coleta.',
              style: TextStyle(
                fontSize: 14,
                height: 1.45,
                color: Colors.green.shade900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusHeader extends StatelessWidget {
  final bool solicitacaoAtiva;

  const _StatusHeader({
    required this.solicitacaoAtiva,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.green.shade700,
            Colors.green.shade600,
          ],
        ),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.recycling,
              color: Colors.white,
              size: 30,
            ),
          ),
          const SizedBox(width: 16),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  solicitacaoAtiva
                      ? 'Coleta solicitada!'
                      : 'Solicitação de coleta',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  solicitacaoAtiva
                      ? 'Acompanhe aqui as próximas etapas.'
                      : 'Confira os dados da sua solicitação.',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.9),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusStep extends StatelessWidget {
  final String titulo;
  final String descricao;
  final bool concluido;
  final bool ultimo;

  const _StatusStep({
    required this.titulo,
    required this.descricao,
    required this.concluido,
    required this.ultimo,
  });

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 32,
            child: Column(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: concluido
                        ? Colors.green.shade700
                        : Colors.grey.shade200,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    concluido
                        ? Icons.check
                        : Icons.circle_outlined,
                    size: concluido ? 18 : 16,
                    color: concluido
                        ? Colors.white
                        : Colors.grey.shade500,
                  ),
                ),

                if (!ultimo)
                  Expanded(
                    child: Container(
                      width: 2,
                      margin: const EdgeInsets.symmetric(
                        vertical: 4,
                      ),
                      color: concluido
                          ? Colors.green.shade300
                          : Colors.grey.shade200,
                    ),
                  ),
              ],
            ),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    titulo,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: concluido
                          ? Colors.black87
                          : Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    descricao,
                    style: TextStyle(
                      fontSize: 13,
                      height: 1.35,
                      color: concluido
                          ? Colors.grey.shade700
                          : Colors.grey.shade500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icone;
  final String titulo;
  final String valor;
  final bool destaque;

  const _InfoRow({
    required this.icone,
    required this.titulo,
    required this.valor,
    this.destaque = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: Colors.green.shade50,
            borderRadius: BorderRadius.circular(11),
          ),
          child: Icon(
            icone,
            color: Colors.green.shade700,
            size: 21,
          ),
        ),

        const SizedBox(width: 12),

        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                titulo,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                valor,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: destaque
                      ? FontWeight.w800
                      : FontWeight.w600,
                  color: destaque
                      ? Colors.green.shade700
                      : Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
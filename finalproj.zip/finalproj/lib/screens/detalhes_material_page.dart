import 'package:flutter/material.dart';
import '../material_data.dart';

class DetalhesMaterialPage extends StatelessWidget {
  final MaterialReciclavel material;

  const DetalhesMaterialPage({
    super.key,
    required this.material,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        title: Text(
          material.nome,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildMaterialHeader(),

            const SizedBox(height: 20),

            _buildSectionTitle('Sobre o material'),

            const SizedBox(height: 8),

            _buildDescriptionCard(),

            const SizedBox(height: 20),

            _buildSectionTitle('Valor estimado'),

            const SizedBox(height: 8),

            _buildPriceCard(),

            const SizedBox(height: 20),

            _buildSectionTitle('Como preparar'),

            const SizedBox(height: 8),

            _buildPreparationCard(),

            const SizedBox(height: 20),

            _buildImportantCard(),

            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.recycling_outlined),
                label: const Text(
                  'Solicitar coleta',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMaterialHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.green,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        children: [
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              shape: BoxShape.circle,
            ),
            child: Icon(
              material.icone,
              color: Colors.white,
              size: 38,
            ),
          ),

          const SizedBox(height: 16),

          Text(
            material.nome,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 6),

          const Text(
            'Material reciclável',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: Colors.black87,
      ),
    );
  }

  Widget _buildDescriptionCard() {
    return _buildCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.info_outline,
            color: Colors.green,
            size: 25,
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Text(
              material.descricao,
              style: TextStyle(
                color: Colors.grey.shade700,
                fontSize: 14,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriceCard() {
    return _buildCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: Colors.green.withValues(alpha: 0.10),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.attach_money,
                  color: Colors.green,
                ),
              ),

              const SizedBox(width: 12),

              const Expanded(
                child: Text(
                  'Valor por quilograma',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 18),

          Text(
            'R\$ ${material.valorPorKg.toStringAsFixed(2)}',
            style: const TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
              color: Colors.green,
            ),
          ),

          const SizedBox(height: 4),

          Text(
            'por kg de ${material.nome.toLowerCase()}',
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 13,
            ),
          ),

          const SizedBox(height: 14),

          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.orange.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.warning_amber_outlined,
                  color: Colors.orange,
                  size: 20,
                ),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Este é um valor estimado. O valor final será calculado de acordo com a pesagem realizada pela equipe no momento da coleta.',
                    style: TextStyle(
                      fontSize: 12,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPreparationCard() {
    final orientacoes = _obterOrientacoes();

    return _buildCard(
      child: Column(
        children: orientacoes
            .asMap()
            .entries
            .map(
              (entry) => _buildPreparationItem(
                numero: entry.key + 1,
                texto: entry.value,
              ),
            )
            .toList(),
      ),
    );
  }

  Widget _buildPreparationItem({
    required int numero,
    required String texto,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 30,
            height: 30,
            alignment: Alignment.center,
            decoration: const BoxDecoration(
              color: Colors.green,
              shape: BoxShape.circle,
            ),
            child: Text(
              '$numero',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Text(
              texto,
              style: TextStyle(
                fontSize: 14,
                height: 1.45,
                color: Colors.grey.shade700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImportantCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.blue.withValues(alpha: 0.15),
        ),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.lightbulb_outline,
            color: Colors.blue,
          ),

          SizedBox(width: 12),

          Expanded(
            child: Text(
              'Dica: mantenha os materiais separados e em boas condições. Isso facilita a organização e a pesagem durante a coleta.',
              style: TextStyle(
                fontSize: 13,
                height: 1.45,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCard({
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: child,
    );
  }

  List<String> _obterOrientacoes() {
    switch (material.nome) {
      case 'Alumínio':
        return [
          'Separe as latas e outros objetos de alumínio dos demais materiais.',
          'Esvazie as embalagens antes de armazená-las.',
          'Se possível, amasse as latas para facilitar o armazenamento.',
          'Mantenha o material seco até o momento da coleta.',
        ];

      case 'Cobre':
        return [
          'Separe fios, cabos e peças de cobre de outros metais.',
          'Mantenha o material organizado e protegido.',
          'Não misture o cobre com resíduos comuns.',
          'Deixe o material pronto para ser identificado e pesado pela equipe.',
        ];

      case 'Papelão':
        return [
          'Separe caixas e embalagens de papelão.',
          'Retire restos de alimentos e outros resíduos.',
          'Desmonte as caixas para ocupar menos espaço.',
          'Mantenha o papelão seco e protegido da chuva.',
        ];

      case 'Papel':
        return [
          'Separe folhas, jornais, revistas e outros papéis recicláveis.',
          'Retire materiais que não sejam papel.',
          'Evite colocar papel molhado junto ao material seco.',
          'Mantenha o papel organizado até a coleta.',
        ];

      case 'Plástico':
        return [
          'Separe as embalagens plásticas dos outros materiais.',
          'Esvazie as embalagens antes de armazená-las.',
          'Quando possível, retire excesso de resíduos.',
          'Mantenha o plástico seco e separado.',
        ];

      case 'Ferro':
        return [
          'Separe peças e objetos de ferro de outros materiais.',
          'Organize as peças para facilitar a coleta.',
          'Não misture o ferro com materiais recicláveis diferentes.',
          'A equipe fará a identificação e pesagem no local.',
        ];

      case 'Aço':
        return [
          'Separe latas e outros objetos de aço.',
          'Esvazie as embalagens antes de armazená-las.',
          'Retire resíduos que possam ser facilmente removidos.',
          'Mantenha o material separado dos demais metais.',
        ];

      case 'PET':
        return [
          'Separe garrafas e embalagens de PET.',
          'Esvazie as embalagens antes de armazená-las.',
          'Quando possível, amasse as garrafas para economizar espaço.',
          'Mantenha o material seco até a coleta.',
        ];

      default:
        return [
          'Separe o material dos demais resíduos.',
          'Mantenha o material limpo e seco sempre que possível.',
          'Organize os recicláveis para facilitar a coleta.',
          'A equipe realizará a identificação e pesagem no local.',
        ];
    }
  }
}
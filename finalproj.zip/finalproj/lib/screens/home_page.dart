import 'package:flutter/material.dart';

import '../app_data.dart';
import 'coleta_page.dart';
import 'materiais_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String get primeiroNome {
    final nome = AppData.nome ?? 'Usuário';

    return nome.split(' ').first;
  }

  String formatarDinheiro(double valor) {
    return 'R\$ ${valor.toStringAsFixed(2).replaceAll('.', ',')}';
  }

  void abrirColeta() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ColetaPage(),
      ),
    );
  }

  void abrirMateriais() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const MateriaisPage(),
      ),
    );
  }

  void mostrarEmBreve(String funcionalidade) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$funcionalidade estará disponível em breve.'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dinheiro = AppData.dinheiroRecebido;
    final pontos = AppData.pontos;

    return Scaffold(
      backgroundColor: const Color(0xFFF6F8F7),

      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.white,

        title: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.recycling,
                color: Colors.green.shade700,
                size: 24,
              ),
            ),

            const SizedBox(width: 12),

            const Text(
              'ReciclaApp',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.black87,
              ),
            ),
          ],
        ),

        actions: [
          IconButton(
            onPressed: () {
              mostrarEmBreve('As notificações');
            },
            icon: const Icon(
              Icons.notifications_none_rounded,
              size: 28,
              color: Colors.black87,
            ),
          ),

          const SizedBox(width: 8),
        ],
      ),

      body: RefreshIndicator(
        onRefresh: () async {
          setState(() {});
        },

        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),

          padding: const EdgeInsets.fromLTRB(
            20,
            20,
            20,
            30,
          ),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ----------------------------------------------------------
              // SAUDAÇÃO
              // ----------------------------------------------------------

              Text(
                'Olá, $primeiroNome! 👋',
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 6),

              Text(
                'Pronto para fazer a diferença hoje?',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey.shade600,
                ),
              ),

              const SizedBox(height: 24),

              // ----------------------------------------------------------
              // CARD DE GANHOS
              // ----------------------------------------------------------

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),

                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),

                  gradient: LinearGradient(
                    colors: [
                      Colors.green.shade800,
                      Colors.green.shade600,
                    ],

                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),

                  boxShadow: [
                    BoxShadow(
                      color: Colors.green.withValues(alpha: 0.20),
                      blurRadius: 18,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

                      children: [
                        const Text(
                          'SEUS GANHOS',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.8,
                          ),
                        ),

                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),

                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(20),
                          ),

                          child: const Row(
                            mainAxisSize: MainAxisSize.min,

                            children: [
                              Icon(
                                Icons.eco_outlined,
                                color: Colors.white,
                                size: 16,
                              ),

                              SizedBox(width: 5),

                              Text(
                                'Recicle e ganhe',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 12),

                    Text(
                      formatarDinheiro(dinheiro),

                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 8),

                    Row(
                      children: [
                        const Icon(
                          Icons.stars_rounded,
                          color: Colors.white,
                          size: 20,
                        ),

                        const SizedBox(width: 6),

                        Text(
                          '$pontos pontos',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              // ----------------------------------------------------------
              // BOTÃO PRINCIPAL
              // ----------------------------------------------------------

              const Text(
                'Comece agora',
                style: TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 14),

              SizedBox(
                width: double.infinity,
                height: 58,

                child: ElevatedButton.icon(
                  onPressed: abrirColeta,

                  icon: const Icon(
                    Icons.local_shipping_outlined,
                    size: 25,
                  ),

                  label: const Text(
                    'Solicitar uma coleta',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade700,
                    foregroundColor: Colors.white,

                    elevation: 0,

                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(17),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 28),

              // ----------------------------------------------------------
              // ACESSOS RÁPIDOS
              // ----------------------------------------------------------

              const Text(
                'Acessos rápidos',
                style: TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 14),

              Row(
                children: [
                  Expanded(
                    child: _MenuCard(
                      icon: Icons.recycling_rounded,
                      titulo: 'Materiais',
                      subtitulo: 'Ver valores',
                      onTap: abrirMateriais,
                    ),
                  ),

                  const SizedBox(width: 14),

                  Expanded(
                    child: _MenuCard(
                      icon: Icons.account_balance_wallet_outlined,
                      titulo: 'Carteira',
                      subtitulo: 'Seus ganhos',
                      onTap: () {
                        mostrarEmBreve('A carteira');
                      },
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 14),

              Row(
                children: [
                  Expanded(
                    child: _MenuCard(
                      icon: Icons.history_rounded,
                      titulo: 'Histórico',
                      subtitulo: 'Suas coletas',
                      onTap: () {
                        mostrarEmBreve('O histórico');
                      },
                    ),
                  ),

                  const SizedBox(width: 14),

                  Expanded(
                    child: _MenuCard(
                      icon: Icons.stars_outlined,
                      titulo: 'Pontos',
                      subtitulo: 'Ver recompensas',
                      onTap: () {
                        mostrarEmBreve('As recompensas');
                      },
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 28),

              // ----------------------------------------------------------
              // PRÓXIMA COLETA
              // ----------------------------------------------------------

              const Text(
                'Sua coleta',
                style: TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 14),

              _CollectionCard(),

              const SizedBox(height: 28),

              // ----------------------------------------------------------
              // COMO FUNCIONA
              // ----------------------------------------------------------

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),

                  border: Border.all(
                    color: Colors.grey.shade200,
                  ),
                ),

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,

                          decoration: BoxDecoration(
                            color: Colors.green.shade50,
                            shape: BoxShape.circle,
                          ),

                          child: Icon(
                            Icons.lightbulb_outline_rounded,
                            color: Colors.green.shade700,
                          ),
                        ),

                        const SizedBox(width: 12),

                        const Text(
                          'Como funciona?',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    const _StepItem(
                      numero: '1',
                      titulo: 'Separe seus recicláveis',
                      descricao:
                          'Organize os materiais que deseja entregar.',
                    ),

                    const SizedBox(height: 12),

                    const _StepItem(
                      numero: '2',
                      titulo: 'Solicite uma coleta',
                      descricao:
                          'Informe os materiais e o endereço da coleta.',
                    ),

                    const SizedBox(height: 12),

                    const _StepItem(
                      numero: '3',
                      titulo: 'Receba pela quantidade',
                      descricao:
                          'Nossa equipe pesa os materiais e calcula o valor.',
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 10),
            ],
          ),
        ),
      ),

      // --------------------------------------------------------------
      // NAVEGAÇÃO INFERIOR
      // --------------------------------------------------------------

      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,

        backgroundColor: Colors.white,

        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Início',
          ),

          NavigationDestination(
            icon: Icon(Icons.recycling_outlined),
            selectedIcon: Icon(Icons.recycling),
            label: 'Coletas',
          ),

          NavigationDestination(
            icon: Icon(Icons.account_balance_wallet_outlined),
            selectedIcon: Icon(
              Icons.account_balance_wallet,
            ),
            label: 'Carteira',
          ),

          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }
}

// ======================================================================
// CARD DE ACESSO RÁPIDO
// ======================================================================

class _MenuCard extends StatelessWidget {
  final IconData icon;
  final String titulo;
  final String subtitulo;
  final VoidCallback onTap;

  const _MenuCard({
    required this.icon,
    required this.titulo,
    required this.subtitulo,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,

      borderRadius: BorderRadius.circular(18),

      child: InkWell(
        onTap: onTap,

        borderRadius: BorderRadius.circular(18),

        child: Container(
          padding: const EdgeInsets.all(17),

          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),

            border: Border.all(
              color: Colors.grey.shade200,
            ),
          ),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
              Container(
                width: 44,
                height: 44,

                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(13),
                ),

                child: Icon(
                  icon,
                  size: 25,
                  color: Colors.green.shade700,
                ),
              ),

              const SizedBox(height: 13),

              Text(
                titulo,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 4),

              Text(
                subtitulo,
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ======================================================================
// CARD DA COLETA
// ======================================================================

class _CollectionCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),

        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),

      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,

            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(16),
            ),

            child: Icon(
              Icons.local_shipping_outlined,
              color: Colors.green.shade700,
              size: 27,
            ),
          ),

          const SizedBox(width: 14),

          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  'Nenhuma coleta agendada',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                SizedBox(height: 5),

                Text(
                  'Solicite uma coleta para começar a reciclar e ganhar.',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.black54,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ======================================================================
// ITEM DE PASSO
// ======================================================================

class _StepItem extends StatelessWidget {
  final String numero;
  final String titulo;
  final String descricao;

  const _StepItem({
    required this.numero,
    required this.titulo,
    required this.descricao,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,

      children: [
        Container(
          width: 32,
          height: 32,

          decoration: BoxDecoration(
            color: Colors.green.shade700,
            shape: BoxShape.circle,
          ),

          alignment: Alignment.center,

          child: Text(
            numero,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),

        const SizedBox(width: 12),

        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [
              Text(
                titulo,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 3),

              Text(
                descricao,
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
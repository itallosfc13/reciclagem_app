import 'package:flutter/material.dart';

import '../app_data.dart';

class PerfilPage extends StatelessWidget {
  const PerfilPage({super.key});

  String valorOuNaoInformado(String? valor) {
    if (valor == null || valor.trim().isEmpty) {
      return 'Não informado';
    }

    return valor;
  }

  String formatarDinheiro(double valor) {
    return 'R\$ ${valor.toStringAsFixed(2).replaceAll('.', ',')}';
  }

  @override
  Widget build(BuildContext context) {
    final nome = valorOuNaoInformado(AppData.nome);

    return Scaffold(
      backgroundColor: const Color(0xFFF7F9F7),
      appBar: AppBar(
        title: const Text(
          'Meu perfil',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _CabecalhoPerfil(
                nome: nome,
                email: valorOuNaoInformado(AppData.email),
              ),

              const SizedBox(height: 24),

              const Text(
                'Informações pessoais',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 12),

              _InformacaoPerfil(
                icone: Icons.person_outline,
                titulo: 'Nome',
                valor: valorOuNaoInformado(AppData.nome),
              ),

              const SizedBox(height: 10),

              _InformacaoPerfil(
                icone: Icons.email_outlined,
                titulo: 'E-mail',
                valor: valorOuNaoInformado(AppData.email),
              ),

              const SizedBox(height: 10),

              _InformacaoPerfil(
                icone: Icons.phone_outlined,
                titulo: 'Telefone',
                valor: valorOuNaoInformado(AppData.telefone),
              ),

              const SizedBox(height: 10),

              _InformacaoPerfil(
                icone: Icons.badge_outlined,
                titulo: 'CPF',
                valor: valorOuNaoInformado(AppData.cpf),
              ),

              const SizedBox(height: 28),

              const Text(
                'Endereço',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 12),

              _EnderecoCard(),

              const SizedBox(height: 28),

              const Text(
                'Resumo da conta',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: _ResumoPerfil(
                      icone: Icons.stars_outlined,
                      titulo: 'Pontos',
                      valor: AppData.pontos.toString(),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _ResumoPerfil(
                      icone: Icons.payments_outlined,
                      titulo: 'Recebido',
                      valor: formatarDinheiro(
                        AppData.dinheiroRecebido,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 28),

              const Text(
                'Coleta',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 12),

              _StatusColeta(),

              const SizedBox(height: 28),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    _mostrarEdicao(context);
                  },
                  icon: const Icon(
                    Icons.edit_outlined,
                  ),
                  label: const Text(
                    'Editar perfil',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade700,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(13),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    _mostrarSair(context);
                  },
                  icon: const Icon(
                    Icons.logout_outlined,
                  ),
                  label: const Text(
                    'Sair da conta',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.red.shade700,
                    side: BorderSide(
                      color: Colors.red.shade200,
                    ),
                    padding: const EdgeInsets.symmetric(
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(13),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _mostrarEdicao(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Editar perfil',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),
          content: const Text(
            'A tela de edição de perfil será criada em uma '
            'próxima etapa. Nela você poderá alterar seus '
            'dados pessoais e informações da conta.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text(
                'Entendi',
              ),
            ),
          ],
        );
      },
    );
  }

  void _mostrarSair(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Sair da conta?',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),
          content: const Text(
            'Você será desconectado desta conta.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text(
                'Cancelar',
              ),
            ),
            TextButton(
              onPressed: () {
                AppData.limparConta();

                Navigator.pop(dialogContext);

                Navigator.popUntil(
                  context,
                  (route) => route.isFirst,
                );
              },
              child: Text(
                'Sair',
                style: TextStyle(
                  color: Colors.red.shade700,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _CabecalhoPerfil extends StatelessWidget {
  final String nome;
  final String email;

  const _CabecalhoPerfil({
    required this.nome,
    required this.email,
  });

  @override
  Widget build(BuildContext context) {
    final primeiraLetra = nome == 'Não informado'
        ? '?'
        : nome.trim().substring(0, 1).toUpperCase();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(21),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 68,
            height: 68,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.green.shade700,
              shape: BoxShape.circle,
            ),
            child: Text(
              primeiraLetra,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),

          const SizedBox(width: 16),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  nome,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                  ),
                ),

                const SizedBox(height: 5),

                Text(
                  email,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InformacaoPerfil extends StatelessWidget {
  final IconData icone;
  final String titulo;
  final String valor;

  const _InformacaoPerfil({
    required this.icone,
    required this.titulo,
    required this.valor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 45,
            height: 45,
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icone,
              color: Colors.green.shade700,
              size: 23,
            ),
          ),

          const SizedBox(width: 13),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titulo,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey.shade600,
                  ),
                ),

                const SizedBox(height: 3),

                Text(
                  valor,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EnderecoCard extends StatelessWidget {
  const _EnderecoCard();

  String valor(String? texto) {
    if (texto == null || texto.trim().isEmpty) {
      return 'Não informado';
    }

    return texto;
  }

  String montarEndereco() {
    final partes = <String>[];

    if (AppData.rua != null && AppData.rua!.isNotEmpty) {
      partes.add(AppData.rua!);
    }

    if (AppData.numero != null && AppData.numero!.isNotEmpty) {
      partes.add('nº ${AppData.numero!}');
    }

    if (AppData.complemento != null &&
        AppData.complemento!.isNotEmpty) {
      partes.add(AppData.complemento!);
    }

    if (AppData.bairro != null &&
        AppData.bairro!.isNotEmpty) {
      partes.add(AppData.bairro!);
    }

    if (AppData.cidade != null &&
        AppData.cidade!.isNotEmpty) {
      partes.add(AppData.cidade!);
    }

    if (AppData.estado != null &&
        AppData.estado!.isNotEmpty) {
      partes.add(AppData.estado!);
    }

    if (partes.isEmpty) {
      return 'Endereço não informado';
    }

    return partes.join(', ');
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                Icons.location_on_outlined,
                color: Colors.green.shade700,
                size: 25,
              ),

              const SizedBox(width: 10),

              Expanded(
                child: Text(
                  montarEndereco(),
                  style: const TextStyle(
                    fontSize: 14,
                    height: 1.45,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 15),

          Divider(
            color: Colors.grey.shade200,
          ),

          const SizedBox(height: 12),

          Row(
            children: [
              Icon(
                Icons.home_outlined,
                size: 20,
                color: Colors.grey.shade600,
              ),

              const SizedBox(width: 10),

              Text(
                'Tipo: ${valor(AppData.tipoResidencia)}',
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.grey.shade700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ResumoPerfil extends StatelessWidget {
  final IconData icone;
  final String titulo;
  final String valor;

  const _ResumoPerfil({
    required this.icone,
    required this.titulo,
    required this.valor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            icone,
            color: Colors.green.shade700,
            size: 24,
          ),

          const SizedBox(height: 10),

          Text(
            titulo,
            style: TextStyle(
              fontSize: 11,
              color: Colors.grey.shade600,
            ),
          ),

          const SizedBox(height: 4),

          Text(
            valor,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusColeta extends StatelessWidget {
  const _StatusColeta();

  @override
  Widget build(BuildContext context) {
    final existeColeta = AppData.coletaSolicitada;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: existeColeta
                  ? Colors.orange.shade50
                  : Colors.grey.shade100,
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(
              existeColeta
                  ? Icons.local_shipping_outlined
                  : Icons.recycling_outlined,
              color: existeColeta
                  ? Colors.orange.shade700
                  : Colors.grey.shade600,
            ),
          ),

          const SizedBox(width: 13),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Status atual',
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  AppData.statusColeta,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
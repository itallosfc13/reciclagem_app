import 'package:flutter/material.dart';

import '../app_data.dart';
import '../material_data.dart';

class HistoricoPage extends StatelessWidget {
  const HistoricoPage({super.key});

  @override
  Widget build(BuildContext context) {
    final temColeta = AppData.coletaSolicitada;

    return Scaffold(
      backgroundColor: const Color(0xFFF7F9F7),
      appBar: AppBar(
        title: const Text(
          'Histórico de coletas',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: SafeArea(
        child: temColeta
            ? const _HistoricoComColeta()
            : const _HistoricoVazio(),
      ),
    );
  }
}

class _HistoricoComColeta extends StatelessWidget {
  const _HistoricoComColeta();

  String formatarDinheiro(double valor) {
    return 'R\$ ${valor.toStringAsFixed(2).replaceAll('.', ',')}';
  }

  double calcularValorEstimado() {
    final materialNome = AppData.materialSelecionado;

    if (materialNome == null || materialNome.isEmpty) {
      return 0;
    }

    try {
      final material = MaterialData.materiais.firstWhere(
        (item) => item.nome == materialNome,
      );

      return material.valorPorKg * AppData.pesoEstimado;
    } catch (_) {
      return 0;
    }
  }

  String get endereco {
    final partes = <String>[];

    if (AppData.rua != null && AppData.rua!.isNotEmpty) {
      partes.add(AppData.rua!);
    }

    if (AppData.numero != null && AppData.numero!.isNotEmpty) {
      partes.add('nº ${AppData.numero!}');
    }

    if (AppData.complemento != null &&
        AppData.complemento!.isNotEmpty) {
      partes.add(AppData.complemento!);
    }

    if (AppData.bairro != null && AppData.bairro!.isNotEmpty) {
      partes.add(AppData.bairro!);
    }

    if (AppData.cidade != null && AppData.cidade!.isNotEmpty) {
      partes.add(AppData.cidade!);
    }

    if (AppData.estado != null && AppData.estado!.isNotEmpty) {
      partes.add(AppData.estado!);
    }

    if (partes.isEmpty) {
      return 'Endereço não informado';
    }

    return partes.join(', ');
  }

  @override
  Widget build(BuildContext context) {
    final valor = calcularValorEstimado();

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Suas coletas',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
            ),
          ),

          const SizedBox(height: 6),

          Text(
            'Confira as informações da sua coleta atual.',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade600,
            ),
          ),

          const SizedBox(height: 20),

          _ColetaCard(
            material:
                AppData.materialSelecionado ?? 'Material reciclável',
            peso: AppData.pesoEstimado,
            observacao: AppData.observacaoColeta ?? '',
            status: AppData.statusColeta,
            valor: valor,
            endereco: endereco,
          ),

          const SizedBox(height: 20),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: Colors.green.shade100,
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.info_outline,
                  color: Colors.green.shade700,
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: Text(
                    'O valor exibido é uma estimativa. '
                    'O valor final será definido após a pesagem '
                    'dos materiais pela equipe de coleta.',
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.45,
                      color: Colors.green.shade900,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ColetaCard extends StatelessWidget {
  final String material;
  final double peso;
  final String observacao;
  final String status;
  final double valor;
  final String endereco;

  const _ColetaCard({
    required this.material,
    required this.peso,
    required this.observacao,
    required this.status,
    required this.valor,
    required this.endereco,
  });

  String formatarDinheiro(double valor) {
    return 'R\$ ${valor.toStringAsFixed(2).replaceAll('.', ',')}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  Icons.recycling_outlined,
                  color: Colors.green.shade700,
                  size: 27,
                ),
              ),

              const SizedBox(width: 14),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      material,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),

                    const SizedBox(height: 4),

                    const Text(
                      'Solicitação atual',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 8),

              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.orange.shade50,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    status,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Colors.orange.shade800,
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          Divider(
            color: Colors.grey.shade200,
          ),

          const SizedBox(height: 16),

          _DetalheColeta(
            icone: Icons.scale_outlined,
            titulo: 'Peso aproximado',
            valor:
                '${peso.toStringAsFixed(2).replaceAll('.', ',')} kg',
          ),

          const SizedBox(height: 14),

          _DetalheColeta(
            icone: Icons.payments_outlined,
            titulo: 'Valor estimado',
            valor: formatarDinheiro(valor),
            destaque: true,
          ),

          const SizedBox(height: 14),

          _DetalheColeta(
            icone: Icons.location_on_outlined,
            titulo: 'Local da coleta',
            valor: endereco,
          ),

          if (observacao.isNotEmpty) ...[
            const SizedBox(height: 14),

            _DetalheColeta(
              icone: Icons.notes_outlined,
              titulo: 'Observação',
              valor: observacao,
            ),
          ],

          const SizedBox(height: 18),

          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'A tela de detalhes da coleta '
                      'será adicionada em breve.',
                    ),
                  ),
                );
              },
              icon: const Icon(
                Icons.visibility_outlined,
              ),
              label: const Text(
                'Ver detalhes',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                ),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.green.shade700,
                side: BorderSide(
                  color: Colors.green.shade300,
                ),
                padding: const EdgeInsets.symmetric(
                  vertical: 13,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DetalheColeta extends StatelessWidget {
  final IconData icone;
  final String titulo;
  final String valor;
  final bool destaque;

  const _DetalheColeta({
    required this.icone,
    required this.titulo,
    required this.valor,
    this.destaque = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icone,
          size: 21,
          color: Colors.green.shade700,
        ),

        const SizedBox(width: 12),

        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                titulo,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),

              const SizedBox(height: 3),

              Text(
                valor,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: destaque
                      ? FontWeight.w800
                      : FontWeight.w600,
                  color: destaque
                      ? Colors.green.shade700
                      : Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _HistoricoVazio extends StatelessWidget {
  const _HistoricoVazio();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.history_outlined,
                size: 50,
                color: Colors.green.shade700,
              ),
            ),

            const SizedBox(height: 24),

            const Text(
              'Nenhuma coleta ainda',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.w800,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              'Quando você solicitar uma coleta, '
              'ela aparecerá aqui.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                height: 1.45,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}